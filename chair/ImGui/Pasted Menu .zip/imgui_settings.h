#include "..\ImGui/imgui.h"

namespace Font
{
	extern ImFont* lexend_general_bold;
	extern ImFont* icomoon_widget2;
	extern ImFont* icomoon_widget;
	extern ImFont* lexend_regular;
	extern ImFont* lexend_bold;
	extern ImFont* icomoon;
	extern ImFont* mainfont;
	extern ImFont* mainfont_smaller;
	extern ImFont* mainfont_bigger;
	extern ImFont* functionfont;
	extern ImFont* icons;

	extern ImFont* interbi;
	extern ImFont* interbinoshift;
	extern ImFont* extreme_fontnoshift;
	extern ImFont* extreme_font;
	extern ImFont* IconFont;

}
